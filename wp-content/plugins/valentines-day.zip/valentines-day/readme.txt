=== Plugin Name ===
Contributors: Sandeep Verma
Donate link: http://www.svnlabs.com
Tags: Saint Valentine's Day, falling hearts, falling tunes
Requires at least: 3.0
Tested up to: 4.3.1
Stable tag: 1.0

Display falling hearts and tunes on Saint Valentine's Day to express love with your website.

== Description ==

Display falling hearts and tunes on Saint Valentine's Day to express love with your website.

== Installation ==

Installing this plugin is quick and easy:

1. Download the WordPress Valentine's Day plugin.
2. Extract the ZIP archive on your computer.
3. Upload the `valentines-day` folder to your `wp-content/plugins` directory.
4. Activate the 'Valentines Day' plugin on your 'Plugins' page in the WordPress dashboard.

== Frequently Asked Questions ==

= How do I configure it? =

Please configuration settings in the `valentines-day/valentines-day.js` file.


this.snowColor = '#f00'; // Use for hearts color

var symbls = new Array('&hearts;','&#9835;', '&bull;');  // falling hearts and tunes array

var sclrs = new Array('#ff0000','#2CAA47','#E8EF1F','#0080FF','#ffffff');  // colors array




== Screenshots ==

1. Screenshot of Front end hearts and tunes falling
2. Screenshot of scriptrr.com


== Changelog ==

= 1.0 =
* Initial release of the WordPress Valentine's Day plugin.


== Arbitrary section ==

Blog: http://blog.svnlabs.com/
Download Plugin: http://valentines.scriptrr.com/

Follow me:

Facebook: http://www.facebook.com/svnlabs
Twitter: http://www.twitter.com/svnlabs

Subscribe me:
Youtube: http://www.youtube.com/user/svnlabs
Feeds: http://blog.svnlabs.com/feed/
